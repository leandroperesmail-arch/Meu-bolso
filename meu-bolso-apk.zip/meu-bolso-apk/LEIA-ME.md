# Meu Bolso: como gerar o APK

## O que você precisa no computador
- Node.js (versão LTS atual): https://nodejs.org
- Android Studio (instala o Android SDK e o JDK que o Gradle usa): https://developer.android.com/studio
  Abra o Android Studio uma vez e deixe ele baixar o SDK.

## Passo a passo
Abra um terminal dentro desta pasta e rode:

    npm install @capacitor/core @capacitor/cli @capacitor/android
    npx cap add android
    npx cap sync android
    cd android
    ./gradlew assembleDebug        (no Windows: gradlew.bat assembleDebug)

O arquivo pronto fica em:

    android/app/build/outputs/apk/debug/app-debug.apk

Se o Gradle reclamar do JDK ou do SDK, abra a pasta `android` no Android Studio
(File > Open) e rode Build > Build APK(s). Ele corrige o caminho do SDK sozinho.

## Instalar no celular
1. Passe o `app-debug.apk` para o aparelho (cabo, Drive, WhatsApp, e-mail).
2. Toque no arquivo. O Android vai pedir para permitir instalar de fontes desconhecidas
   para o app que você usou para abri-lo (Arquivos, Chrome etc.). Permita.
3. Toque em Instalar.

## Observações
- É um APK de depuração: serve para uso pessoal, mas não para a Play Store.
- Os lançamentos ficam só no aparelho. Desinstalar o app ou limpar os dados dele apaga tudo.
- O botão "Exportar mês (CSV)" e a sincronização com a conta do Claude não existem no APK.
- As fontes (Inter e Bricolage Grotesque) vêm da internet. Sem conexão o app usa a fonte do sistema.
- Para trocar o ícone, substitua os arquivos `ic_launcher*` em `android/app/src/main/res/mipmap-*`.
